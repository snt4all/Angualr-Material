A Pen created at CodePen.io. You can find this one at http://codepen.io/jbltx/pen/KwQxBX.

 This is a simple way to create picture header like Google Material Design with Angular Material. The default md-toolbar is used here and stylized with an other directive to listen on scroll and resize event.